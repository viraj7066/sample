import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Options from './components/Options';
import Services from './components/Services';
import About from './components/About';
import Footer from './components/Footer';
import Logo from './components/Logo';
import { LogIn } from 'lucide-react';

function App() {
  return (
    <main className="min-h-screen bg-white">
      <div className="fixed top-4 left-6 z-50">
        <Logo />
      </div>
      <div className="fixed top-4 right-6 z-50 md:block hidden">
        <button className="flex items-center space-x-2 px-6 py-2.5 bg-navy-600 text-white rounded-full hover:bg-navy-700 transition-all duration-300 transform hover:scale-105">
          <LogIn size={20} />
          <span>Login</span>
        </button>
      </div>
      <Navbar />
      <Hero />
      <Options />
      <Services />
      <About />
      <Footer />
    </main>
  );
}

export default App;