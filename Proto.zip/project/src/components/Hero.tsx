import React, { useEffect } from 'react';
import { motion } from 'framer-motion';

const Hero = () => {
  useEffect(() => {
    const loadVanta = async () => {
      const VANTA = (window as any).VANTA;
      if (VANTA) {
        VANTA.BIRDS({
          el: "#hero-background",
          mouseControls: true,
          touchControls: true,
          gyroControls: false,
          minHeight: 200.00,
          minWidth: 200.00,
          scale: 1.00,
          scaleMobile: 1.00,
          backgroundColor: 0xffffff,
          color1: 0x000000,
          color2: 0x1a365d
        });
      }
    };
    loadVanta();
  }, []);

  return (
    <div id="hero-background" className="relative h-screen w-full bg-gradient-to-b from-gray-50 to-white overflow-hidden">
      <motion.h1 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="absolute top-1/2 -translate-y-1/2 inset-x-0 flex items-center justify-center text-[15vw] font-black text-black pointer-events-none select-none tracking-tighter"
      >
        PROTOFORM.
      </motion.h1>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col">
        <div className="flex-1 flex flex-col justify-end pb-20">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-center space-y-8"
          >
            <h2 className="text-2xl font-bold text-gray-800">
              Giving wings to your imagination with precision crafting.
            </h2>
            <p className="text-xl sm:text-2xl max-w-2xl mx-auto text-gray-600">
              The 3D printing service that brings your ideas to life with precision and innovation
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default Hero;