import React, { useState, useEffect } from 'react';
import { Menu, X, ShoppingCart } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <div className="fixed w-full z-50 flex justify-between items-center px-6 py-4">
        {/* Circular Navbar */}
        <nav className={`fixed left-1/2 top-4 -translate-x-1/2 px-12 py-3 rounded-full transition-all duration-300 ${
          isScrolled ? 'bg-black/60 backdrop-blur-md' : 'bg-black'
        }`}>
          <div className="hidden md:flex items-center space-x-12">
            {['Services', 'About', 'Contact', 'Login'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="text-gray-300 hover:text-[#FF8C42] transition-colors duration-300 text-sm"
              >
                {item}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-300 hover:text-[#FF8C42]"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden fixed top-20 left-1/2 -translate-x-1/2 w-[90%] max-w-md bg-black/90 backdrop-blur-md rounded-2xl shadow-lg py-4 px-4">
            {['Services', 'About', 'Contact', 'Login'].map((item) => (
              <a
                key={item}
                href={`#${item.toLowerCase()}`}
                className="block py-3 text-gray-300 hover:text-[#FF8C42] transition-colors duration-300 text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                {item}
              </a>
            ))}
            <button className="w-full mt-2 flex items-center justify-center space-x-2 px-6 py-2.5 bg-[#FF8C42] text-black rounded-full hover:bg-[#FF7C32] transition-all duration-300">
              <ShoppingCart size={20} />
              <span>Shop Now</span>
            </button>
          </div>
        )}
      </div>
      {/* Orange line under navbar */}
      <div className="fixed w-full z-40 top-[4.5rem]">
        <div className="h-[2px] bg-[#FF8C42] w-full opacity-50"></div>
      </div>
    </>
  );
};

export default Navbar;